import React from 'react';
import styles from './card.module.css';
const Card =(props)=> {
    const {image,title,price,alt} =props;
    return ( 
        <article className={styles.cardWrapper}>
            <img src={image} alt={alt} />
            <h4>{title}</h4>
            <p>{price}</p>
        </article>
     );
}

export default Card;
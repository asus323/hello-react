import React from 'react';
import {CardWrapper} from './cardElements';
import Card from './card';
import iphonePic from '../../images/iphone.jpg';
import mac from '../../images/mac.jpg';
const Cards =()=>{
return (
    <CardWrapper>
        <Card image={iphonePic} title="iphone 13pro max" price="130000000 $" alt="iphone 13promax" />
        <Card image={mac} title="iphone 13pro max" price="130000000 $" alt="iphone 13promax" />
        <Card image={mac} title="iphone 13pro max" price="130000000 $" alt="iphone 13promax" />
    </CardWrapper>
);
}

export default Cards;
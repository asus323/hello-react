import React from 'react';
import styles from './footer.module.css';
function Footer() {
    return ( 
        <footer className={styles.footer}>all copyright reserved by Me</footer>
     );
}

export default Footer;